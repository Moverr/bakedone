# Overview #

* [MO (mobile office)](../../../mobileoffice/wiki/Home)
* [CDS (client data storage)](../../../clientdatastorage/wiki/Home)
* [ID (awamo ID generator)](../../../id_generator/wiki/Home)
* CRM (customer relationship management)
    * [Backend CRM](../../../crm_backend/wiki/Home)
    * [Frontend CRM](../../../crm_frontend/wiki/Home)
* [MIS (management information system)](../../../managementinformationsystem/wiki/Home)
* [PE (process engine)](../../../processengine/wiki/Home)
* [AU (authentication server)](../../../authenticationserver/wiki/Home)
* [Overview](../../../overview/wiki/)