/* global Storage */

// '##tenantId##' will be replaced with correct value by CockpitEndpoint on delivery
//var tenantId = '##tenantId##'; // TODO change before productive deployment
var tenantId = 'test23'; 

var clientList = new ClientList();
var loanList = new LoanList();

var handlers = {
    Loan: new LoanHandler(),
    SavingsAccount: new SavingsAccountHandler(),
    Communication: new CommunicationHandler(),
    Reporting: new ReportingHandler(),
    Inbox: new InboxHandler(),
    Dashboard: new DashboardHandler()
};

//var host = 'http://' + window.location.host;
var host = 'http://localhost:5000'; // TODO change before productive deployment
var username = null;
var authentication = null;
var user = null;
var currentTable = 'none';

var tenant = {
    name: 'awamo MFI ltd.',
    manager: {
        id: 8,
        username: 'cockpituser1',
        firstname: 'Dirk',
        lastname: 'Podolak',
        fullname: 'Podolak, Dirk',
        phone1: '+49-123-4567890',
        email: 'podolak@awamo.com'
    }
};

function getAuthenticationHeader() {
    return { tenantId: tenantId, authentication: authentication };
};

function ajax(url, type, successCallback, data, headers, failCallback) {
    if (typeof headers === "undefined") {
        headers = getAuthenticationHeader();
    }
    
//    console.log('call ' + type + " " + host + url + ' with data:');
//    console.log(data);
//    console.trace();
    
    if (typeof(failCallback) === "undefined") {
        failCallback = function(e) {
            console.log('fail');
            console.log(e);
        };
    }
    
    $.ajax({
            url: host + url,
            type: type,
            data: data,
            headers: headers,
            dataType: 'json',
            contentType: "application/json; charset=utf-8"
        })
        .done(successCallback)
        .fail(failCallback)
        .always(function (e) {
    //            console.log('always');
    //            console.log(e);
        });
};

/* initialization */
function initApp() {
};

function initLocalStorage() {
    if (typeof (Storage) !== "undefined") {
        // noop
    } else {
        // Sorry! No Web Storage support..
    }
};

function initLogin() {
    // init and start login
    $('#loginForm').submit(handlers['Communication'].loginFormSubmitHandler);
    $('.forgotPasswordLink a').on('click touch', function () {
        $('#actionValue').val('forgotPassword');
        $('#loginRow input').removeAttr('required');
        $('#forgotPasswordRow input').attr('required', 'required');
        $('#loginRow').hide();
        $('#forgotPasswordRow').show();
        $('.message').hide();
    });

    $('.backToLoginLink a').on('click touch', function () {
        $('#actionValue').val('login');
        $('#loginRow input').attr('required', 'required');
        $('#forgotPasswordRow input').removeAttr('required');
        $('#loginRow').show();
        $('#forgotPasswordRow').hide();
        $('.message').hide();
    });
};

$(document).ready(function () {
    initApp();
    initLocalStorage();
    initLogin();
    
    // start with login
    $('#login').show();
});
