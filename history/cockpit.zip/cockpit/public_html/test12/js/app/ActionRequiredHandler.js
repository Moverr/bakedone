/* global handlers, savingsAccountList, loanList, shareList */

var ActionRequiredHandler = function() {
    ActionRequiredHandler.self = this;
    loanList.addDataModelChangedEventListenerCallback(ActionRequiredHandler.prototype._dataModelChanged);
    savingsAccountList.addDataModelChangedEventListenerCallback(ActionRequiredHandler.prototype._dataModelChanged);
    shareList.addDataModelChangedEventListenerCallback(ActionRequiredHandler.prototype._dataModelChanged);
};

ActionRequiredHandler.OVERVIEW_TITLES = {
    type: 'Type',
    number: 'Number'
};

/* external */
ActionRequiredHandler.prototype.overview = function() {
    hideContent();
    $('h3.page-header').text('Action required');
    $('h3.page-header').show();
    $('h4.sub-header').hide();
    
    currentTable = 'actionRequired';
    
    var $rowContainer = getDefaultRowContainer(ActionRequiredHandler.OVERVIEW_TITLES);
    var loanApplicationsNumber = $('span[data-counterkey="loanApplications"]').data('counter');
    var loanDisbursementsNumber = $('span[data-counterkey="loanDisbursements"]').data('counter');
    var savingsAccountApplicationsNumber = $('span[data-counterkey="savingsAccountApplications"]').data('counter');
    //var sharePurchaseApplicationsNumber = $('span[data-counterkey="sharePurchaseApplications"]').data('counter');
    //var shareSaleApplicationsNumber = $('span[data-counterkey="shareSaleApplications"]').data('counter');
    
    addRow($rowContainer, { type: 'Loan applications', number: '<span data-counter="' + loanApplicationsNumber + '" data-counterkey="loanApplications">' + loanApplicationsNumber + '</span>' }, 'Loan', ActionRequiredHandler.self.rowClickHandler, 'getApplications');
    addRow($rowContainer, { type: 'Loan disbursements', number: '<span data-counter="' + loanDisbursementsNumber + '" data-counterkey="loanDisbursements">' + loanDisbursementsNumber + '</span>' }, 'Loan', ActionRequiredHandler.self.rowClickHandler, 'getDisbursements');
    addRow($rowContainer, { type: 'Savings account applications', number: '<span data-counter="' + savingsAccountApplicationsNumber + '" data-counterkey="savingsAccountApplications">' + savingsAccountApplicationsNumber + '</span>' }, 'SavingsAccount', ActionRequiredHandler.self.rowClickHandler, 'getApplications');
    
//    addRow($rowContainer, { type: 'Purchase share', number: 0 }, 'Share', ActionRequiredHandler.self.rowClickHandler, 'purchase');
//    addRow($rowContainer, { type: 'Approve share purchase', number: sharePurchaseApplicationsNumber }, 'Share', ActionRequiredHandler.self.rowClickHandler, 'approvePurchase');
//    addRow($rowContainer, { type: 'Sell share', number: 0 }, 'Share', ActionRequiredHandler.self.rowClickHandler, 'sale');
//    addRow($rowContainer, { type: 'Approve share sale', number: shareSaleApplicationsNumber }, 'Share', ActionRequiredHandler.self.rowClickHandler, 'approveSale');
};

ActionRequiredHandler.prototype.rowClickHandler = function() {
    var action = $(this).data('id');
    var handler = $(this).data('object');
    $('li[data-parent~="actionRequired"][data-handler="' + handler + '"][data-action~="' + action + '"] a').click();
};

/* internal */
ActionRequiredHandler.prototype._loanApplicationsRowClickHandler = function() {
    $('#actionRequired-loanApplications').click();
};

ActionRequiredHandler.prototype._loanDisbursementsRowClickHandler = function() {
    $('#actionRequired-loanDisbursements').click();
};

ActionRequiredHandler.prototype._savingsAccountApplicationsRowClickHandler = function() {
    $('#actionRequired-savingsAccountApplications').click();
};

ActionRequiredHandler.prototype._savingsAccountApplicationsRowClickHandler = function() {
    $('#actionRequired-savingsAccountApplications').click();
};

ActionRequiredHandler.prototype._dataModelChanged = function() {
    // update badges
    var loanApplicationsNumber = loanList.getSubmittedCount();
    var loanDisbursementsNumber = loanList.getContractSignedCount();
    var savingsAccountApplicationsNumber = savingsAccountList.getCountByStatus('SUBMITTED_FOR_PURCHASE');
    //var sharePurchaseApplicationsNumber = shareList.getCountByStatus('SUBMITTED_FOR_PURCHASE');
    //var shareSaleApplicationsNumber = shareList.getCountByStatus('SUBMITTED_FOR_SALE');
    var sharePurchaseApplicationsNumber = 0;
    var shareSaleApplicationsNumber = 0;
    
    var $counterspan;
    
    $counterspan = $('span[data-counterkey="loanApplications"]');
    $counterspan.data('counter', loanApplicationsNumber);
    $counterspan.text(loanApplicationsNumber);
    if (loanApplicationsNumber === 0 && !$counterspan.parent().is('td')) {
        $counterspan.hide();
    } else {
        $counterspan.show();
    }
    
    $counterspan = $('span[data-counterkey="loanDisbursements"]');
    $counterspan.data('counter', loanDisbursementsNumber);
    $counterspan.text(loanDisbursementsNumber);
    if (loanDisbursementsNumber === 0 && !$counterspan.parent().is('td')) {
        $counterspan.hide();
    } else {
        $counterspan.show();
    }
    
    $counterspan = $('span[data-counterkey="savingsAccountApplications"]');
    $counterspan.data('counter', savingsAccountApplicationsNumber);
    $counterspan.text(savingsAccountApplicationsNumber);
    if (savingsAccountApplicationsNumber === 0 && !$counterspan.parent().is('td')) {
        $counterspan.hide();
    } else {
        $counterspan.show();
    }

//    $counterspan = $('span[data-counterkey="sharePurchaseApplications"]');
//    $counterspan.data('counter', sharePurchaseApplicationsNumber);
//    $counterspan.text(sharePurchaseApplicationsNumber);
//    if (sharePurchaseApplicationsNumber === 0 && !$counterspan.parent().is('td')) {
//        $counterspan.hide();
//    } else {
//        $counterspan.show();
//    }
//    
//    $counterspan = $('span[data-counterkey="shareSaleApplications"]');
//    $counterspan.data('counter', shareSaleApplicationsNumber);
//    $counterspan.text(shareSaleApplicationsNumber);
//    if (shareSaleApplicationsNumber === 0 && !$counterspan.parent().is('td')) {
//        $counterspan.hide();
//    } else {
//        $counterspan.show();
//    }
    
    $counterspan = $('span[data-counterkey="actionRequired"]');
    $counterspan.data('counter', loanApplicationsNumber + loanDisbursementsNumber + savingsAccountApplicationsNumber + sharePurchaseApplicationsNumber + shareSaleApplicationsNumber);
    $counterspan.text(loanApplicationsNumber + loanDisbursementsNumber + savingsAccountApplicationsNumber + sharePurchaseApplicationsNumber + shareSaleApplicationsNumber);
    if (loanApplicationsNumber + loanDisbursementsNumber + savingsAccountApplicationsNumber + sharePurchaseApplicationsNumber + shareSaleApplicationsNumber === 0 && !$counterspan.parent().is('td')) {
        $counterspan.hide();
    } else {
        $counterspan.show();
    }
};
