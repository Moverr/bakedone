'use strict';

/* global clientList, savingsAccountList, handlers, currencyCode */

var ClientHandler = function () {
    ClientHandler.self = this;
    clientList.addEntityChangedEventListenerCallback(ClientHandler.prototype.entityChanged);
    
    $('#singleClientActions a').on('click touch', ClientHandler.self._singleClientActionHandler);
};

ClientHandler.ALL_CLIENTS_TITLES = {
    // client image
    awamoId: 'awamo ID',
    fullname: 'Name',
    gender: 'Sex',
    birthdate: 'Birth date',
    submitDate: 'Registration'    
};

ClientHandler.ACCOUNTS_TITLES = {
    accountNo: 'Account',
    type: 'Type',
    status: 'Status',
    interestRate: 'Interest',
    balance: 'Balance'
};

// <editor-fold defaultstate="collapsed" desc=" public methods ">
ClientHandler.prototype.getAll = function () {
    currentTable = 'allClients';
    ClientHandler.self.previousPage = ClientHandler.self.getAll;
    ClientHandler.self.displayClients();
};

ClientHandler.prototype.loadClients = function () {
    clientList.reload();
};
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc=" private methods ">
ClientHandler.prototype.displayClients = function () {
    ClientHandler.self.currentClient = null;
    
    initDefaultContent('All clients');
    
    $('#syncNow').off('click touch');
    $('#syncNow').on('click touch', ClientHandler.self.synchronizeNow);
    $('#syncNow').show();

    var dataList = clientList.getEntities();
    var $rowContainer = getDefaultRowContainer(ClientHandler.ALL_CLIENTS_TITLES);
    var $table= $rowContainer.parent();
    
    for (var i = 0; i < dataList.length; i++) {
        var rowdata = {};

        for (var key in ClientHandler.ALL_CLIENTS_TITLES) {
            var formattedValue = dataList[i][key];
            if ('birthdate' === key || 'submitDate' === key) {
                formattedValue = formatDate(formattedValue);
            }
            rowdata[key] = formattedValue;
        }

        addRow($rowContainer, rowdata, dataList[i], ClientHandler.self.rowClickHandler, dataList[i].accountId);
    }

    var tableSorter = getDefaultTableSorter();
    tableSorter.headers = {
        3: { sorter: 'awamoDateSorter' },
        4: { sorter: 'awamoDateSorter' }
    };
    $table.tablesorter(tableSorter);
    
    $('#tableTotal').text(dataList.length);
    showContent($('#tableTotalSum'));
};

ClientHandler.prototype.rowClickHandler = function () {
    ClientHandler.self.displayOneClient($(this).data('object'));
};

ClientHandler.prototype.displayOneClient = function (client) {
    // check parameter
    if (!exists(client)) {
        return;
    }
    
    // store current client
    ClientHandler.self.client = client;

    // hide all content
    hideContent();
    
    // header
    $('.navbar-content').show();
    $('h3.page-header').text('Client');
    $('h3.page-header').show();
    $('h4.sub-header').hide();
    
    ClientHandler.self.displayClientData(client);
    ClientHandler.self.displayAccountsData(client);

    // show necessary content
    showContent($('#accountsTableContainer'));
    showContent($('#client'));
};

ClientHandler.prototype.displayClientData = function (client) {
    // client
    $('#client .panel-heading').text(client.fullname);
    $('#clientAwamoId').val(client.awamoId);
    $('#clientFirstName').val(client.firstname);
    $('#clientMiddleName').val(client.middlename);
    $('#clientLastName').val(client.lastname);
    $('#clientBirthdate').val(formatDate(client.birthdate) + ' (' + client.age + ' years)');
    $('#clientNationality').val(client.nationality);
    $('#clientSubmitdate').val(formatDate(client.submitDate));
    
    $('#clientIdDocumentType').val(client.iddocumenttype);
    $('#clientIdDocument').val(client.iddocument);
    $('#clientPhone1').val(client.phone1);
    $('#clientPhone2').val(client.phone2);
    $('#clientGender').val(client.gender);
    $('#clientLocation').val(client.site);
};

ClientHandler.prototype.displayAccountsData = function (client) {
    var $rowContainer = getRowContainer('#accountsTableContainer', ClientHandler.ACCOUNTS_TITLES);
    var $table= $rowContainer.parent();
    var savingsAccounts = savingsAccountList.getByClient(client.awamoId);
    var len = savingsAccounts.length;

    for (var i = 0; i < len; i++) {
        var savingsAccount = savingsAccounts[i];
        var formattedRowData = ClientHandler.prototype._getAccountsRowData(savingsAccount);
        addRow($rowContainer, formattedRowData, savingsAccount, ClientHandler.self._accountsRowClickHandler, savingsAccount.accountId);
    }
    
    var tableSorter = getDefaultTableSorter();
    tableSorter.headers = {
        3: { sorter: 'awamoPercentageSorter' },
        4: { sorter: 'awamoCurrencySorter' }
    };
    $table.tablesorter(tableSorter);
    addClassToTableColumn($table, 4, 'currency');
};

ClientHandler.prototype._getAccountsRowData = function (savingsAccount) {
    var rowdata = {};

    for (var key in ClientHandler.ACCOUNTS_TITLES) {
        var formattedValue = savingsAccount[key];
        
        switch (key) {
            case 'type':
                formattedValue = 'savings account';
                break;
            case 'interestRate':
                formattedValue = formatPercentage(formattedValue) + ' %';
                break;
            case 'balance':
                formattedValue = formatCurrency(formattedValue) + ' ' + currencyCode;
                break;
            default:
                break;
        }
        
        rowdata[key] = String(formattedValue);
    }

    return rowdata;
};

ClientHandler.prototype._accountsRowClickHandler = function () {
    var savingsAccount = $(this).data('object');
    var savingsAccountHandler = handlers['SavingsAccount'];
    var event = { currentTarget: { } };
    $(event.currentTarget).data('object', savingsAccount);
    savingsAccountHandler.rowClickHandler(event, function() { ClientHandler.self.displayOneClient(ClientHandler.self.client); });
};

ClientHandler.prototype._singleClientActionHandler = function (event) {
    event.preventDefault();
    hideContent();

    switch ($(this).data('action')) {
        case 'back':
            ClientHandler.self.previousPage();
            break;
        default:
            // noop
            break;
    }
};

ClientHandler.prototype.outputClient = function (client) {
    var $row = null;
    // update badges
    var clientNumber = clientList.getTotalCount();
    
    // update GUI
    if ('allClients' === currentTable) {
        //$row = ClientHandler.self.addToTable(client);
    } else {
        // noop
    }
    
    return $row;
};

ClientHandler.prototype.entityChanged = function(client) {
    ClientHandler.self.outputClient(client);
};

ClientHandler.prototype.synchronizeNow = function() {
    clientList.reload();
};
