/* global handlers, tenantId, authentication, host, username, handleMainMenu, tenant, URL, loanList, clientList, officerList, groupList, savingsAccountList, accountList, shareList */

var CommunicationHandler = function () {
    CommunicationHandler.self = this;
};

/* external */
CommunicationHandler.prototype.loginFormSubmitHandler = function (event) {
    event.preventDefault();

    var actionValue = $('#actionValue').val(); // login or forgotPassword

    if ('login' === actionValue) {
        $('.loginFormSubmitButtonText').hide();
        $('.loginFormSubmitButtonImage').show();
        statusbar('waiting for server reply on login');

        var headers = {
            tenantId: tenantId,
            username: $('#loginname').val(),
            password: $('#password').val()
        };

        username = headers['username'];

        ajax(
                '/tenant/v1d/mis/user',
                'GET',
                CommunicationHandler.self.loginResponseHandler,
                null,
                headers,
                CommunicationHandler.self.loginFailedHandler
                );
    } else if ('forgotPassword' === actionValue) {
        // not using default ajax call here because user handling is done against a different endpoint
        headers = {
            tenantId: tenantId,
            data: $('#forgotPasswordData').val()
        };

        ajax(
                '/tenant/v1d/mis/forgotPassword',
                'POST',
                CommunicationHandler.self.forgotPasswordResponseHandler,
                null,
                headers,
                CommunicationHandler.self.forgotPasswordFailedHandler);
    } else {
        // TODO
    }
};

/* internal */
CommunicationHandler.prototype.loginResponseHandler = function (userResponse) {
    statusbar('login successful');

    authentication = userResponse.authentication;
    user = userResponse;
    user.fullname = user.lastname + ", " + user.firstname;

    ajax(
            '/tenant/v1d/currencycode',
            'GET',
            function (currencyResponse) {
                console.log(currencyResponse.code);
                currencyCode = currencyResponse.code;
                localStorage['currencyCode'] = currencyCode;
            }
    );

    $.ajax({
        url: host + '/officer/binarydata/v1d/find?' +
                'awamoId=' + user.officerMasterData.awamoId + '&' +
                'deviceId=cockpit&' +
                'datatype=PHOTOGRAPHY',
        type: 'GET',
        headers: getAuthenticationHeader(),
        xhrFields: {
            responseType: 'arraybuffer'
        }
    })
            .done(function (e) {
                var blob = new Blob([e], {type: "image/jpg"});
                var fr = new FileReader();
                fr.onload = function (e) {
                    localStorage['icon'] = e.target.result;
                    $('#dashboardProfile img').attr('src', localStorage['icon']);
                    $('#profilePanel img').attr('src', localStorage['icon']);
                };
                fr.readAsDataURL(blob);
            })
            .fail(function (e) {
                console.log('fail');
                console.log(e);
            })
            .always(function (e) {
                //            console.log('always');
                //            console.log(e);
            });

    $('#username').val(username);

    // init menu handler
    $('.navbar-fixed-top a.navbar-brand').on('click touch', function () {
        $('#dashboard a').click();
    });
    $('.navbar-fixed-top .nav li ul li').on('click touch', CommunicationHandler.prototype.handleMainMenu);
    $('.sidebar .nav li').on('click touch', CommunicationHandler.prototype.sidebarNavigationHandler);

    // init navigation
    $('nav.navbar-fixed-top ul.nav').show();
    $('#login').hide();
    $('.sidebar').show();
    $('.main').show();

    // init content (start with dashboard)
    handlers['Dashboard'].init();

    // start background loading of data
    CommunicationHandler.self.initData();
    statusbar('loading data');
};

CommunicationHandler.prototype.initData = function () {
    var initializerList = [
        groupList,
        officerList,
        loanList,
        savingsAccountList,
        accountList,
        shareList
    ];
    clientList.init(initializerList);
};

CommunicationHandler.prototype.loginFailedHandler = function (response) {
    user = null;
    username = null;

    $('.loginbox .message').show();
    $('.loginFormSubmitButtonText').show();
    $('.loginFormSubmitButtonImage').hide();
};

CommunicationHandler.prototype.forgotPasswordResponseHandler = function (response) {
    user = null;
    username = null;

    $('.loginbox .message').text('A new password has been sent to your email address. Please check your mail and try to login with the new password.');
    $('.loginbox .message').show();
    $('#actionValue').val('login');
    $('#loginRow input').attr('required', 'required');
    $('#forgotPasswordRow input').removeAttr('required');
    $('#loginRow').show();
    $('#forgotPasswordRow').hide();
    $('.loginFormSubmitButtonText').show();
    $('.loginFormSubmitButtonImage').hide();
};

CommunicationHandler.prototype.forgotPasswordFailedHandler = function (response) {
    user = null;
    username = null;

    $('.loginbox .message').html('Your password request was not successful, please try again to enter valid data.<br>If you do not have a user name yet contact awamo support to register a new account. If you already have a user name, please check the spelling or contact awamo support.');
    $('.loginbox .message').show();
    $('.loginFormSubmitButtonText').show();
    $('.loginFormSubmitButtonImage').hide();
};

/* navigation */
CommunicationHandler.prototype.sidebarNavigationHandler = function () {
    var openParent = function ($listitem) {
        var speed = 350;
        var id = $listitem.attr('id');
        var $subitems = $listitem.parent().find('.subitem[data-parent!="' + id + '"]');
        $subitems.each(function (index, subitem) {
            $(subitem).animate({height: '0'}, speed, function () {
                $(subitem).addClass('hidden');
            });
        });

        var $subitems = $listitem.parent().find('[data-parent="' + id + '"]');
        $subitems.each(function (index, subitem) {
            $(subitem).removeClass('hidden');
            $(subitem).animate({height: $(subitem).css('max-height')}, speed);
        });
    };

    var $li = $(this);

    /* move active state on navbar items */
    $('.sidebar .nav li.active').removeClass('active');
    $li.addClass('active');

    if ($li.hasClass('parentitem')) {
        openParent($li);
    } else if ($li.hasClass('subitem')) {
        openParent($('#' + $li.data('parent')));
    }

    /* dispatch to action handler */
    var handler = $li.data('handler');
    var action = $li.data('action');
    var args = $li.data('args');

    if (exists(handler) && exists(action)) {
        handlers[handler][action](args);
    }
};

CommunicationHandler.prototype.handleMainMenu = function () {
    var $li = $(this);

    /* dispatch to action handler */
    var handler = $li.data('handler');
    var action = $li.data('action');
    var args = $li.data('args');

    if (exists(handler) && exists(action)) {
        handlers[handler][action](args);
    }
};

CommunicationHandler.prototype.showProfile = function () {
    hideContent();

    // general header
    $('h3.page-header').text('Profile');
    $('h3.page-header').show();
    $('h4.sub-header').hide();

    // fill data
    $('#profilePanel .panel-heading span').text(user.fullname);
    var profileArea = $('#profileArea');
    profileArea.find('input[data-target]').each(function () {
        $(this).val(getTargetFromObject($(this), user));
    });
    // TODO image

    // show content
    showContent(profileArea);
};

CommunicationHandler.prototype.showAccount = function () {
    hideContent();

    // general header
    $('h3.page-header').text('Account');
    $('h3.page-header').show();
    $('h4.sub-header').hide();

    // fill data
    $('#accountPanel .panel-heading span').text(tenant.name);
    var accountArea = $('#accountArea');
    accountArea.find('input[data-target]').each(function () {
        $(this).val(getTargetFromObject($(this), tenant));
    });

    // show content
    showContent(accountArea);
};

CommunicationHandler.prototype.help = function () {
    hideContent();
    $('h3.page-header').text('Help & Support');
    $('h3.page-header').show();
    $('h4.sub-header').hide();

    var helpArea = $('#helpOverview');



    showContent(helpArea);
};

CommunicationHandler.prototype.logout = function () {
    ajax(
            '/tenant/v1d/mis/logout',
            'POST',
            undefined,
            undefined,
            undefined,
            undefined,
            undefined
            );
    location.reload();
};

CommunicationHandler.prototype.about = function () {
    initDefaultContent('About');

    $('h4.sub-header').html('<p id="aboutLink">Please visit our <a href="http://www.awamo.com" target="_blank">homepage</a> to get more information about awamo.</p>');
    $('h4.sub-header').show();
};

/* ContactMessage */
CommunicationHandler.prototype.sendMessage = function () {
    // not using default ajax call here because user handling is done against a different endpoint
    headers = {
        tenantId: tenantId
    };

    var uri = '/tenant/v1d/mis/contactForm';
    var body = '{"name":"' + $('#nameC').val() +
            '","phone":"' + $('#phoneNumberC').val() +
            '","email":"' + $('#emailC').val() +
            '","message":"' + $('#messageC').val() +
            '","subject":"' + $('#subjectC').val() +
            '"}';
    ajax(uri, 'POST', CommunicationHandler.prototype.messageSentResponseHandler, body, headers);

};

CommunicationHandler.prototype.messageSentResponseHandler = function (response) {
    $('#sendMessageStatus').text('Sent Successfully');
};

CommunicationHandler.prototype.messageSentFailedResponseHandler = function (response) {
    $('#sendMessageStatus').text('Sent Failed');
};
