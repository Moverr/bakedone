/* global shareList, clientList, savingsAccountList, MessageType, currencyCode */

var ShareHandler = function() {
    ShareHandler.self = this;
    
    $('#singleActions a').off('click touch');
    $('#singleActions a').on('click touch', ShareHandler.prototype.singleObjectActionHandler);
    
    this.commandStack = [];
    this.argumentStack = [];
    
    shareList.addDataModelChangedEventListenerCallback(ShareHandler.prototype.dataModelChanged);
    shareList.addEntityChangedEventListenerCallback(ShareHandler.prototype.entityChanged);
    
    $('#singleActions a').off('click touch');
    $('#singleActions a').on('click touch', ShareHandler.prototype.singleObjectActionHandler);
};

ShareHandler.APPLICATION_TITLES = {
    accountId: 'Account ID',
    client: 'Client',
    savingsAccountNumber: 'Savings Account',
    status: 'Status'
};

// <editor-fold defaultstate="collapsed" desc=" apply for purchase ">
ShareHandler.prototype.purchase = function() {
    ShareHandler.self.stack(ShareHandler.prototype.purchase);
    ShareHandler.self.share = null;
    initDefaultContent('Purchase share');
    var $clientSelect = $('#shareClient');
    var $savingsAccountSelect = $('#shareSavingsAccount');
    
    clientList
            .getEntities()
            .filter(function(client) { return savingsAccountList.getByClient(client.awamoId).length > 0; })
            .sort(function(one, other) { return one.fullname > other.fullname; })
            .forEach(function(client) {
                $clientSelect.append($('<option value="' + client.awamoId + '">' + client.fullname + '</option>'));
    });
    $clientSelect.on('input', function() {
        $savingsAccountSelect.find('option').not(':first').remove();
        savingsAccountList.getByClient($(this).val()).forEach(function(savingsAccount) {
            $savingsAccountSelect.append($('<option value="' + savingsAccount.accountId + '">' + savingsAccount.accountNo + '</option>'));
        });
    });
    
    $('#singleActions a[data-action="purchase"]').text('Purchase');
    $('#shareCount').on('input', function() {
        var value = Math.round(Math.abs($(this).val()));
        if (value === 0) {
            $('#singleActions a[data-action="purchase"]').text('Purchase');
        } else {
            $('#singleActions a[data-action="purchase"]').text('purchase ' + value + ' share' + (value ===  1 ? '' : 's') + ' for ' + (value * 500) + ' ' + currencyCode);
        }
    });
    $('#shareCount').next('.input-group-addon').text('500 ' + currencyCode);

    $('#shareApplicationForm').on('submit', ShareHandler.prototype.submitPurchaseApplicationHandler);

    $('#sharePurchaseDatePicker').datetimepicker({
        weekStart: 1,
        todayBtn: 1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: 2,
        forceParse: 1,
        pickerPosition: 'bottom-center',
        keyboardNavigation: 0
    });
    $('#sharePurchaseDatePicker').datetimepicker('setValue'); // show "today" in input field
    ShareHandler.self.showActionButtons();
    
    showContent($('#shareApplication'));
};

ShareHandler.prototype.submitPurchaseApplicationHandler = function(event) {
    if (exists(event)) {
        event.preventDefault();
    }
    
    var numberOfShares = Math.round(Math.abs($('#shareCount').val()));
    var shareApplication = {
        awamoId: $('#shareClient').val(),
        submittedDate: new Date($('#sharePurchaseDate').val()).getTime(),
        savingsAccountId: $('#shareSavingsAccount').val(),
        requestedShares: numberOfShares
    };
    
    ajax(shareList.rootPath, 'POST', function(response) {
        message('Success',
            'successfully submitted application for purchase of ' + numberOfShares + ' share' + (numberOfShares ===  1 ? '' : 's') + ' for ' + (numberOfShares * 500) + ' ' + currencyCode,
            MessageType.SUCCESS);
            
        $('#sharePurchaseDatePicker').datetimepicker('setDate', new Date());
        $('#shareClient').find('option').not(':first').remove();
        $('#shareSavingsAccount').find('option').not(':first').remove();
        $('#shareCount').val('');
        $('#singleActions a[data-action="purchase"]').text('Purchase');
        $('#singleActions a[data-action="purchase"]').prop('disabled', true);
        
        $('#sharePurchaseDatePicker').blur();
        $('#shareClient').blur();
        $('#shareSavingsAccount').blur();
        $('#shareCount').blur();
        $('#singleActions a[data-action="purchase"]').blur();
    }, JSON.stringify(shareApplication), undefined, function(response) {
        message('Error', response.responseJSON.message, MessageType.WARNING);
    });
};
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc=" approve/reject purchase application ">
ShareHandler.prototype.approvePurchase = function() {
    ShareHandler.self.stack(ShareHandler.prototype.approvePurchase);
    initDefaultContent('Purchase applications');
    var $rowContainer = getDefaultRowContainer(ShareHandler.APPLICATION_TITLES);
    var filteredList = shareList.getListByStatus('SUBMITTED_FOR_PURCHASE');
    
    if (filteredList.length === 0) {
        tableMessage('no share purchase applications found');
    }
    
    filteredList.forEach(function(share) {
        addRow(
            $rowContainer,
            ShareHandler.self.getShareRowData(share),
            share,
            ShareHandler.self.approvePurchaseRowClickHandler,
            share.accountId);
    });
    
    $rowContainer.parent().tablesorter(getDefaultTableSorter());
    
    showContent($('#defaultTableContainer'));
};

ShareHandler.prototype.approvePurchaseRowClickHandler = function () {
    // register new button handler
    $('#approveNo').off('click touch');
    $('#approveNo').on('click touch', ShareHandler.prototype.back);
    $('#rejectNo').off('click touch');
    $('#rejectNo').on('click touch', ShareHandler.prototype.back);
    
    $('#approveYes').off('click touch');
    $('#approveYes').on('click touch', ShareHandler.prototype.approvePurchaseApplication);
    $('#rejectYes').off('click touch');
    $('#rejectYes').on('click touch', ShareHandler.prototype.rejectPurchaseApplication);
    
    $('#approveApplication .panel-body .approvalObject').text('share purchase');
    $('#rejectApplication .panel-body .rejectionObject').text('share purchase');
    
    ShareHandler.self.displaySingleShare($(this).data('object'));
};

ShareHandler.prototype.approvePurchaseApplication = function () {
    ShareHandler.self.share.status = 'APPROVED_PURCHASE';
    ajax(
            shareList.rootPath + ShareHandler.self.share.id + '/approvePurchase',
            'POST',
            ShareHandler.prototype.approvePurchaseApplicationSuccessful);
    ShareHandler.self.back();
    ShareHandler.self.back();
};

ShareHandler.prototype.approvePurchaseApplicationSuccessful = function () {
    ShareHandler.self.share.status = 'APPROVED_PURCHASE';
    shareList.put(shareList, ShareHandler.self.share);
};

ShareHandler.prototype.rejectPurchaseApplication = function () {
    ShareHandler.self.share.status = 'REJECTED_PURCHASE';
    ajax(
            shareList.rootPath + ShareHandler.self.share.id + '/rejectPurchase',
            'POST',
            ShareHandler.prototype.rejectPurchaseApplicationSuccessful,
            '{"note":"' + $('#rejectionNote').val() + '"}');
    ShareHandler.self.back();
    ShareHandler.self.back();
};

ShareHandler.prototype.rejectPurchaseApplicationSuccessful = function () {
    ShareHandler.self.share.status = 'REJECTED_PURCHASE';
    shareList.put(shareList, ShareHandler.self.share);
};
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc=" apply for sale ">
ShareHandler.prototype.sale = function() {
    ShareHandler.self.stack(ShareHandler.prototype.sale);
    initDefaultContent('Sell share');
    var $rowContainer = getDefaultRowContainer(ShareHandler.APPLICATION_TITLES);

    shareList.getEntities().filter(function (share) {
        return share.status === 'ACTIVE';
    }).forEach(function (share) {
        addRow(
                $rowContainer,
                ShareHandler.self.getShareRowData(share),
                share,
                ShareHandler.self.saleRowClickHandler,
                share.accountId);
    });
    
    $('#singleShareForm').on('submit', ShareHandler.prototype.submitSaleApplicationHandler);
    $rowContainer.parent().tablesorter(getDefaultTableSorter());

    showContent($('#defaultTableContainer'));
};

ShareHandler.prototype.saleRowClickHandler = function () {
    var share = $(this).data('object');
    ShareHandler.self.displaySingleShare(share);
    
// at the moment it is not possible to sell some shares, you can only sell all
//    $('#shareSaleCount').prop('max', share.requestedShares);
//    $('#shareSaleGroup').show();
//    
//    $('#singleActions a[data-action="sell"]').text('Sell');
//    $('#shareSaleCount').on('input', function () {
//        var value = Math.round(Math.abs($(this).val()));
//        if (value === 0) {
//            $('#singleActions a[data-action="sell"]').text('Sell');
//        } else {
//            $('#singleActions a[data-action="sell"]').text('sell ' + value + ' share' + (value === 1 ? '' : 's') + ' for ' + (value * 500) + ' ' + currencyCode);
//        }
//    });

$('#shareSaleCount').val(share.requestedShares);
};

ShareHandler.prototype.submitSaleApplicationHandler = function(event) {
    if (exists(event)) {
        event.preventDefault();
    }
    
    var numberOfShares = Math.round(Math.abs($('#shareSaleCount').val()));
    var shareTransaction = {
        requestedShares: numberOfShares
    };
    
    ajax(shareList.rootPath + ShareHandler.self.share.id + '/redeem', 'POST', function(response) {
        message('Success',
            'successfully submitted application for sale of ' + numberOfShares + ' share' + (numberOfShares ===  1 ? '' : 's') + ' for ' + (numberOfShares * 500) + ' ' + currencyCode,
            MessageType.SUCCESS);
    }, JSON.stringify(shareTransaction), undefined, function(response) {
        message('Error', response.responseJSON.message, MessageType.WARNING);
        ShareHandler.self.share.status = 'ACTIVE';
        shareList.put(shareList, ShareHandler.self.share);
    });
    
    ShareHandler.self.share.status = 'SUBMITTED_FOR_SALE';
    shareList.put(shareList, ShareHandler.self.share);
    ShareHandler.self.back();
};
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc=" approve/reject sale application ">
ShareHandler.prototype.approveSale = function() {
    ShareHandler.self.stack(ShareHandler.prototype.approveSale);
    initDefaultContent('Sell applications');
    var $rowContainer = getDefaultRowContainer(ShareHandler.APPLICATION_TITLES);
    var filteredList = shareList.getListByStatus('SUBMITTED_FOR_SALE');
    
    if (filteredList.length === 0) {
        tableMessage('no share sale applications found');
    }
    
    filteredList.forEach(function (share) {
        addRow(
                $rowContainer,
                ShareHandler.self.getShareRowData(share),
                share,
                ShareHandler.self.approveSaleRowClickHandler,
                share.accountId);
    });

    showContent($('#defaultTableContainer'));
};

ShareHandler.prototype.approveSaleRowClickHandler = function () {
    // register new button handler
    $('#approveNo').off('click touch');
    $('#approveNo').on('click touch', ShareHandler.prototype.back);
    $('#rejectNo').off('click touch');
    $('#rejectNo').on('click touch', ShareHandler.prototype.back);
    
    $('#approveYes').off('click touch');
    $('#approveYes').on('click touch', ShareHandler.prototype.approveSaleApplication);
    $('#rejectYes').off('click touch');
    $('#rejectYes').on('click touch', ShareHandler.prototype.rejectSaleApplication);
  
    $('#approveApplication .panel-body .approvalObject').text('share sale');
    $('#rejectApplication .panel-body .rejectionObject').text('share sale');
    
    ShareHandler.self.displaySingleShare($(this).data('object'));
};

ShareHandler.prototype.approveSaleApplication = function () {
    ShareHandler.self.share.status = 'APPROVED_SALE';
    ajax(
            shareList.rootPath + ShareHandler.self.share.id + '/approveSale',
            'POST',
            ShareHandler.prototype.approveSaleApplicationSuccessful);
    ShareHandler.self.back();
    ShareHandler.self.back();
};

ShareHandler.prototype.approveSaleApplicationSuccessful = function () {
    ShareHandler.self.share.status = 'APPROVED_SALE';
    shareList.put(shareList, ShareHandler.self.share);
};

ShareHandler.prototype.rejectSaleApplication = function () {
    ShareHandler.self.share.status = 'REJECTED_SALE';
    ajax(
            shareList.rootPath + ShareHandler.self.share.id + '/rejectSale',
            'POST',
            ShareHandler.prototype.rejectPurchaseApplicationSuccessful,
            '{"note":"' + $('#rejectionNote').val() + '"}');
    ShareHandler.self.back();
    ShareHandler.self.back();
};

ShareHandler.prototype.rejectSaleApplicationSuccessful = function () {
    ShareHandler.self.share.status = 'REJECTED_SALE';
    shareList.put(shareList, ShareHandler.self.share);
};
// </editor-fold>

// <editor-fold defaultstate="collapsed" desc=" common methods ">
ShareHandler.prototype.displayApprove = function(share) {
    ShareHandler.self.stack(ShareHandler.prototype.displayApprove, share);
    hideContent();
    showContent($('#approveApplication'));
};

ShareHandler.prototype.displayReject = function(share) {
    ShareHandler.self.stack(ShareHandler.prototype.displayReject, share);
    hideContent();
    $('#rejectionNote').val('');
    showContent($('#rejectApplication'));
};

ShareHandler.prototype.getShareRowData = function(share) {
    var rowdata = {};
    
    for (var key in ShareHandler.APPLICATION_TITLES) {
        var formattedValue = share[key];
        
        switch (key) {
            case 'client':
                formattedValue = share.awamoId;
                break;
            default:
                break;
        }
        
        rowdata[key] = String(formattedValue);
    }

    return rowdata;
};

ShareHandler.prototype.displaySingleShare = function (share) {
    ShareHandler.self.stack(ShareHandler.prototype.displaySingleShare, share);
    ShareHandler.self.share = share;
    
    // hide all content
    hideContent();
    
    // set data
    $('#singleSharePurchaseDate').val(formatDate(share.submittedDate));
    $('#singleShareClient').val(share.awamoId);
    $('#singleShareSavingsAccount').val(share.savingsAccountId);
    $('#singleShareCount').val(share.requestedShares);
    $('#singleShareCount').next('.input-group-addon').text('500 ' + currencyCode);
    
    // handle buttons
    ShareHandler.self.showActionButtons();
    
    // show form
    showContent($('#singleShare'));
};

ShareHandler.prototype.singleObjectActionHandler = function() {
    var action = $(this).data('action');

    switch (action) {
        case 'approve':
            ShareHandler.self.displayApprove(ShareHandler.self.share);
            break;
        case 'reject':
            ShareHandler.self.displayReject(ShareHandler.self.share);
            break;
        case 'back':
            ShareHandler.self.back();
            break;
        case 'purchase':
            $('#shareApplicationForm input[type="submit"]').click();
            break;
        case 'sell':
            $('#singleShareForm input[type="submit"]').click();
            break;
        default:
            // noop
            break;
    }
};

ShareHandler.prototype.showActionButtons = function() {
    $('#singleActions a[data-action]').hide();
    
    if (ShareHandler.self.share === null) {
        $('#singleActions a[data-action="purchase"]').show();
    } else {
        $('#singleActions a[data-action="back"]').show();
        
        switch (ShareHandler.self.share.status) {
            case 'SUBMITTED_FOR_PURCHASE':
            case 'SUBMITTED_FOR_SALE':
                $('#singleActions a[data-action="approve"]').show();
                $('#singleActions a[data-action="reject"]').show();
                break;
            case 'ACTIVE':
                $('#singleActions a[data-action="sell"]').show();
                break;
            default:
                break;
        }
    }
    
    showContent($('#singleActions'));
};

ShareHandler.prototype.dataModelChanged = function() {
    // NOOP
};

ShareHandler.prototype.entityChanged = function(object, type) {
//    switch (type) {
//        case eventtype.CREATE:
//        case eventtype.UPDATE:
//            //ShareHandler.self.outputLoan(object);
//            break;
//        case eventtype.DELETE:
//            // TODO
//            console.log('not yet implemented: loan entity [' + object.mainId + '] deleted');
//            break;
//        default:
//            break;
//    }
};

ShareHandler.prototype.stack = function(command, arguments) {
    ShareHandler.self.commandStack.push(command);
    ShareHandler.self.argumentStack.push(arguments); // TODO: don't know if this works if it is undefined ...
};

ShareHandler.prototype.back = function() {
    // remove current page from stack
    ShareHandler.self.commandStack.pop();
    ShareHandler.self.argumentStack.pop();
    
    // call previous page
    ShareHandler.self.commandStack.pop()(ShareHandler.self.argumentStack.pop());
};
// </editor-fold>
