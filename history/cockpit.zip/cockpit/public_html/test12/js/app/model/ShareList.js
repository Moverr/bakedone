'use strict';

/* global AbstractList */

var ShareList = function() {
    AbstractList.call(this);

    this.rootPath = '/share/v1d/';
    this.entityName = 'share';
    this.storagePrefix = this.entityName + '_';
};

ShareList.prototype = Object.create(AbstractList.prototype, {
    constructor: ShareList,
    enrich: { value: function(object) {
        object.mainId = object.id;
        return object;
    }, enumerable: true },
    getCountByStatus: { value: function(status) {
        return this.getEntities().reduce(function (accumulator, object) {
            if (object.status === status) {
                accumulator = accumulator + 1;
            }
            return accumulator;
        }, 0);
    }, enumerable: true },
    getListByStatus: { value: function(status) {
        return this.getEntities().filter(function(share) { return share.status === status; });
    }, enumerable: true }
});
